const url = 'https://chat-gpt26.p.rapidapi.com/';
const options = {
	method: 'POST',
	headers: {
		'content-type': 'application/json',
		'Content-Type': 'application/json',
		'X-RapidAPI-Key': 'bf7eab2c20msh74b4a841553bd21p17d736jsn0583fb914d80',
		'X-RapidAPI-Host': 'chat-gpt26.p.rapidapi.com'
	},
	body: {
		model: 'gpt-3.5-turbo',
		messages: [
			{
				role: 'user',
				content: 'Hello'
			}
		]
	}
};

{response => response.json()}
try {
	const response = await fetch(url, options);
	const result = await response.text();
	console.log(result);
    console.log(response.content)
} catch (error) {
	console.error(error);
}